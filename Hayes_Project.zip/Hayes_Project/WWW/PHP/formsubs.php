<html>
<body>
<div>
<div>
            Welcome <?php echo $_POST["name"]; ?><br>
            Thank you for your comment: <?php echo $_POST["comment"]; ?>
</div>
</div>
</body>
</html>